﻿

namespace HelloWorldAPI
{
    using System.Web.Http;

    using HelloWorldInfrastructure.FrameworkWrappers;
    using System.Collections.Generic;
    using HelloWorldInfrastructure.Mappers;
    using HelloWorldInfrastructure.Services;
    using LightInject;

    public static class LightInjectConfig
    {

        public static void Register(HttpConfiguration config)
        {
            var container = new ServiceContainer();
            container.RegisterApiControllers();        

            container.EnablePerWebRequestScope();
            container.EnableWebApi(GlobalConfiguration.Configuration);
            container.EnableMvc();

            RegisterServices(container);
        }

        private static void RegisterServices(IServiceRegistry serviceRegistry)
        {

            serviceRegistry.Register<IAppSettings, ConfigAppSettings>();

            // Register default Logger Service
            ////serviceRegistry.Register<ILogger, JsonL4NLogger>();
            serviceRegistry.RegisterInstance(typeof(ILogger), new JsonL4NLogger());

            // Register default Hosting Environment Service
            serviceRegistry.Register<IHostingEnvironmentService, ServerHostingEnvironmentService>();

            // Register default File IO Service
            serviceRegistry.Register<IFileIOService, TextFileIOService>();

            // Register default Data Service
            serviceRegistry.Register<IDataService, HelloWorldDataService>();

            // Register default DateTime wrapper
            serviceRegistry.Register<IDateTime, SystemDateTime>();

            // Register default Hello World mapper
            serviceRegistry.Register<IHelloWorldMapper, HelloWorldMapper>();
        }
    }
}
