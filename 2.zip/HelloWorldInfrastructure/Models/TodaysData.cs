﻿
namespace HelloWorldInfrastructure.Models
{

    public class TodaysData
    {

        public string Data { get; set; }
    }
}