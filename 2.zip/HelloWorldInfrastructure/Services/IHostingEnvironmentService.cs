﻿

namespace HelloWorldInfrastructure.Services
{

    public interface IHostingEnvironmentService
    {

        string MapPath(string path);
    }
}