﻿

namespace HelloWorldInfrastructure.Services
{
    using System.Configuration;

    public class ConfigAppSettings : IAppSettings
    {

        public string Get(string name)
        {
            return ConfigurationManager.AppSettings.Get(name);
        }
    }
}