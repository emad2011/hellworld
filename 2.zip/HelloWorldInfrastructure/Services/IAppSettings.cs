﻿

namespace HelloWorldInfrastructure.Services
{

    public interface IAppSettings
    {

        string Get(string name);
    }
}