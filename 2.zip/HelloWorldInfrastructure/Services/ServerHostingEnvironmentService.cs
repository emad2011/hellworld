﻿

namespace HelloWorldInfrastructure.Services
{
    using System.Web.Hosting;

    /// <summary>
    ///     Service for Server Hosting Environment
    /// </summary>
    public class ServerHostingEnvironmentService : IHostingEnvironmentService
    {

        public string MapPath(string path)
        {
            return HostingEnvironment.MapPath("~/" + path);
        }
    }
}