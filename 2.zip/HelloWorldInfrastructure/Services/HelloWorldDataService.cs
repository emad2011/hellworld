﻿

namespace HelloWorldInfrastructure.Services
{
    using System.Configuration;
    using HelloWorldInfrastructure.FrameworkWrappers;
    using HelloWorldInfrastructure.Mappers;
    using HelloWorldInfrastructure.Models;
    using HelloWorldInfrastructure.Resources;


    public class HelloWorldDataService : IDataService
    {

        private readonly IAppSettings appSettings;


        private readonly IDateTime dateTimeWrapper;

 
        private readonly IFileIOService fileIOService;

        private readonly IHelloWorldMapper helloWorldMapper;


        public HelloWorldDataService(
            IAppSettings appSettings,
            IDateTime dateTimeWrapper,
            IFileIOService fileIOService,
            IHelloWorldMapper helloWorldMapper)
        {
            this.appSettings = appSettings;
            this.dateTimeWrapper = dateTimeWrapper;
            this.fileIOService = fileIOService;
            this.helloWorldMapper = helloWorldMapper;
        }


        public TodaysData GetTodaysData()
        {
            // Get the file path
            var filePath = this.appSettings.Get(AppSettingsKeys.TodayDataFileKey);

            if (string.IsNullOrEmpty(filePath))
            {
                // No file path was found, throw exception
                throw new SettingsPropertyNotFoundException(
                    ErrorCodes.TodaysDataFileSettingsKeyError, 
                    new SettingsPropertyNotFoundException("The TodayDataFile settings key was not found or had no value."));
            }

            // Get the data from the file
            var rawData = this.fileIOService.ReadFile(filePath);

            // Add the timestamp
            rawData += " as of " + this.dateTimeWrapper.Now().ToString("F");

            // Map to the return type
            var todaysData = this.helloWorldMapper.StringToTodaysData(rawData);

            return todaysData;
        }
    }
}