﻿
namespace HelloWorldInfrastructure.Services
{

    public interface IFileIOService
    {

        string ReadFile(string filePath);
    }
}