﻿

namespace HelloWorldInfrastructure.FrameworkWrappers
{
    using System;


    public interface IDateTime
    {

        DateTime Now();
    }
}