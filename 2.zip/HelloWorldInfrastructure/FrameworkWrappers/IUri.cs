﻿
namespace HelloWorldInfrastructure.FrameworkWrappers
{
    using System;


    public interface IUri
    {

        Uri GetUri(string uriString);
    }
}