﻿

namespace HelloWorldInfrastructure.Resources
{
    public class AppSettingsKeys
    {

        public const string TodayDataFileKey = "TodaysDataFile";


        public const string HelloWorldApiUrlKey = "HelloWorldAPIURL";
    }
}
